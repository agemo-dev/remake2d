#include <remake2d/all/bases.hpp>
#include <remake2d/all/tools.hpp>
#include <remake2d/tilegrid.hpp>
#include <remake2d/actor.hpp>
#include <remake2d/sound.hpp>
#include <remake2d/data.hpp>

#include <string>
#include <deque>
#include <vector>

class Snake : public rmk::Actor {

public:
    using Segment = rmk::Area;
	
private:
    std::deque<Segment>  m_body;         // Snake's segments, head at front(), tail at back()
    rmk::Window&         m_win;         // Window to draw the snake into
    rmk::TileGrid&       m_zone;        // Game grid (used to know the field boundaries)
    rmk::Timer           m_tick{0.15};  // Timer that paces movement (1 step every 0.15s)
    rmk::Vec2d           m_velocity{1, 0}; // Current direction (in "cells": x/y are -1, 0 or 1)
    rmk::Vec2d           m_start_center;   // Starting position (needed to support "restart")
    rmk::f32             m_start_size;     // Starting segment size (needed to support "restart")
    bool                 m_grow{false};    // True for one frame right after eating an apple
    bool                 m_alive{true};    // False once the snake has died (collision)
    bool                 m_paused{false};  // True while the game is paused (P key)

public:
    Snake(const rmk::Area& head, rmk::Window& win, rmk::TileGrid& zone)
        : m_win(win), m_zone(zone), m_start_center(head.center()), m_start_size(head.w) {
			_resetBody(); // builds the initial body (head + 2 segments)
    }

public:
    void update(void) override {
        if (!m_alive) return; // dead snake: nothing moves anymore

        // Advance by one cell only when the timer has elapsed
        // (and the game isn't paused), which sets the snake's speed.
        if (!m_paused && m_tick.isElapsed()) {
            rmk::f32   size    = m_body.front().w;          // size of one cell
            rmk::Vec2d current = m_body.front().center();   // current head position
            rmk::Vec2d offset  = m_velocity * size;         // one-cell move in current direction
            rmk::Vec2d next    = current + offset;          // next head position

            // Collision with the field border or with the snake's own body = death
            if (_isOutOfBounds(next) || _hitsSelf(next)) {
                m_alive = false;
                return;
            }

            // Add a new head at the new position...
            rmk::Vec2d topLeft = { next.x - size / 2.0f, next.y - size / 2.0f };
            Segment head(topLeft.x, topLeft.y, size, size);
            m_body.emplace_front(head);

            // ...and if no apple was eaten, drop the tail
            // (otherwise keep it: the snake grows by one segment).
            if (m_grow) {
                m_grow = false;
            } else {
                m_body.pop_back();
            }

            m_tick.start(); // restart the timer for the next step
        }

        // Draw the snake: each segment is filled with a progressively lighter
        // green further from the head (simple gradient on the green channel).
        rmk::f32 hue = 25;
        for (const auto& seg : m_body) {
            m_win.fill(seg, rmk::color::green - rmk::Color{0, (rmk::byte)hue, 0, 0});
            hue = hue < 200 ? hue * 1.1f : 200; // capped so it never exceeds max color value
        }
    }

public:
    // Changes direction, unless it's a direct U-turn
    // (prevents the snake from running straight into its own neck).
    void velocity(rmk::Vec2d v) {
        if (v.x != -m_velocity.x || v.y != -m_velocity.y) m_velocity = v;
    }

    // Triggers growth on the next step (called when an apple is eaten)
    void grow(void) noexcept {
        m_grow = true;
    }

    // Toggles pause/resume (P key)
    void togglePause(void) noexcept {
        m_paused = !m_paused;
    }

    // Restarts a fresh game from the initial state (0 key after Game Over)
    void restart(void) noexcept {
        _resetBody();
    }

    // Head position (center), used to test collision with the apple
    rmk::Vec2d headCenter(void) const noexcept {
        return m_body.front().center();
    }

    // True if the given point is occupied by any segment of the snake
    // (used to avoid respawning the apple on top of the snake).
    bool occupies(const rmk::Vec2d& point) const noexcept {
        for (const auto& seg : m_body) {
            if (seg.center() == point) return true;
        }
        return false;
    }

    bool isAlive(void)  const noexcept {
        return m_alive;
    }

    bool isPaused(void) const noexcept {
        return m_paused;
    }

private:
    // (Re)builds the snake's body from its starting position/size.
    // Used both in the constructor AND on restart, to avoid duplicating logic.
    void _resetBody(void) noexcept {
        m_body.clear();

		auto& size   = m_start_size;
		auto& center = m_start_center;
		
        rmk::Vec2d headTopLeft = { center.x - size / 2.0f, center.y - size / 2.0f };
        Segment head(headTopLeft.x, headTopLeft.y, size, size);
        m_body.emplace_back(head);

        // Add 2 body segments aligned behind the head (to the left)
        for (rmk::usize i = 0; i < 2; i++) {
            rmk::Vec2d lastCenter = m_body.back().center();
            rmk::Vec2d nextCenter = { lastCenter.x - size, lastCenter.y };
            
            rmk::Vec2d segTopLeft = { nextCenter.x - size / 2.0f, nextCenter.y - size / 2.0f };
            Segment tmp(segTopLeft.x, segTopLeft.y, size, size);
            m_body.emplace_back(tmp);
        }

        // Reset all game state
        m_velocity = {1, 0};
        m_grow     = false;
        m_alive    = true;
        m_paused   = false;
        m_tick.start();
    }

    // True if the given position is outside the game grid (m_zone) boundaries
    bool _isOutOfBounds(const rmk::Vec2d& pos) const noexcept {
        rmk::Vec2d center = m_zone.center();
        rmk::Dim2d size   = m_zone.size();
        rmk::f32 left     = center.x - size.w / 2.0f;
        rmk::f32 right    = center.x + size.w / 2.0f;
        rmk::f32 top      = center.y - size.h / 2.0f;
        rmk::f32 bottom   = center.y + size.h / 2.0f;

        return pos.x < (left - 0.1f) || pos.x > (right + 0.1f) || 
               pos.y < (top - 0.1f)  || pos.y > (bottom + 0.1f);
    }

    // True if the given position hits the snake's body (excluding the very
    // last cell, which will disappear this turn if the snake isn't growing).
    bool _hitsSelf(const rmk::Vec2d& pos) const noexcept {
        for (rmk::usize i = 0; i < m_body.size() - 1; i++) {
            if (m_body[i].center() == pos) return true;
        }
        return false;
    }
};

// The apple to eat: a simple shape (Circle) repositioned to a random free
// cell on the grid each time it's eaten.
class Apple  {
private:
    rmk::Circle m_shape;

public:
    Apple(const rmk::Vec2d& pos, rmk::f32 size) : m_shape(pos, size) {}

public:
    // Picks a random cell on the grid, looping while the snake occupies it,
    // so the apple never spawns on top of the snake.
    void respawn(rmk::TileGrid& zone, const Snake& snake) noexcept {
        rmk::Vec2d pos;
        do {
            rmk::u32 idx    = rmk::random.rand<rmk::u32>(0, zone.count() - 1);
            rmk::Grid2d coo = { idx % zone.cut().x, idx / zone.cut().x };
            pos = zone.cell(coo).center();
        } while (snake.occupies(pos));

        m_shape.move(pos);
    }

    void draw(rmk::Window& win) noexcept {
        win.fill(m_shape, rmk::color::red);
    }

    rmk::Vec2d center(void) const noexcept {
        return m_shape.center();
    }
};