#include <remake2d/all/everything.hpp>

namespace rmk {
namespace config {
namespace solstat {

void initLuaUtility(sol::table& rmk) noexcept {

	rmk["currentVersion"] = &currentVersion;

    rmk["pi"] = pi;

    rmk["angle"].get_or_create<sol::table>();
    rmk["angle"]["degToRad"] = &angle::degToRad;
    rmk["angle"]["radToDeg"] = &angle::radToDeg;

	rmk["color"].get_or_create<sol::table>();
    rmk["color"]["RGBToHSL"] = &color::RGBToHSL;
    rmk["color"]["HSLToRGB"] = &color::HSLToRGB;

	rmk["physic"].get_or_create<sol::table>();
    rmk["physic"]["pixelToMeter"] = sol::overload(
        [](f32 pixels) { return physic::pixelToMeter(pixels); },
        [](const Vec2d& pixels) { return physic::pixelToMeter(pixels); },
        [](const Dim2d& pixels) { return physic::pixelToMeter(pixels); }
    );

    rmk["physic"]["meterToPixel"] = sol::overload(
        [](f32 meters) { return physic::meterToPixel(meters); },
        [](const Vec2d& meters) { return physic::meterToPixel(meters); },
        [](const Dim2d& meters) { return physic::meterToPixel(meters); }
    );

    rmk["fail"]     = fail;
    rmk["success"]  = success;
    rmk["on"]       = on;
    rmk["off"]      = off;
    rmk["isTrue"]   = isTrue;
    rmk["isFalse"]  = isFalse;

    rmk["file"].get_or_create<sol::table>();
    rmk["file"]["jump"] = [](std::vector<std::string_view> views) -> std::string {
    	return file::jump(views);
	};
    rmk["file"]["createParentPath"] = &file::createParentPath;
}

} // namespace solstat
} // namespace config
} // namespace rmk