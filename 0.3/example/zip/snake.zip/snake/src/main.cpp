#include "include.hpp"

namespace {
    // Window and side-panel dimensions.
    // Final layout: [ cmd (full height) | game | score / status ]
    constexpr rmk::i32 SIDE_W  = 220;
    constexpr rmk::i32 GAME_W  = 510;
    constexpr rmk::i32 GAME_H  = 450;
    constexpr rmk::i32 WIN_W   = SIDE_W * 2 + GAME_W; // 950
    constexpr rmk::i32 WIN_H   = 500;
    constexpr rmk::i32 PANEL_H = WIN_H / 2;            // 250: height of the score/status panels

    constexpr rmk::u64 VOLUME = 80; // default volume for music/sfx (0-128)
}

int main(void) {
    rmk::Window win("snake", rmk::window::pos::centered, { (rmk::f32)WIN_W, (rmk::f32)WIN_H });

    rmk::u32   score(0);
    rmk::imax  highscore(0);         // best score, loaded from the save file
    rmk::Vec2d velocity(1, 0);       // current snake direction (set by key presses)
    constexpr rmk::Color primaryColor(20, 70,  200, 255);
    constexpr rmk::Color secondaryColor(70, 150, 200, 255);

    // --- Defining the window's 3 zones (viewports) ---
    // cmd    : left strip, full height (controls list)
    // score  : top-right (current score + best score)
    // status : bottom-right ("GAME OVER" / "PAUSE" message)

    rmk::Window::Viewport cmdViewport    (rmk::Area (0,              0,        SIDE_W,   WIN_H));
    rmk::Window::Viewport scoreViewport  (rmk::Area (WIN_W - SIDE_W, 0,        SIDE_W, PANEL_H));
    rmk::Window::Viewport statusViewport (rmk::Area (WIN_W - SIDE_W, PANEL_H,  SIDE_W, PANEL_H));

    win.connectViewport(cmdViewport);
    win.connectViewport(scoreViewport);
    win.connectViewport(statusViewport);

    // Game grid: 17x15 cells, centered in the space left between the panels
    rmk::TileGrid zone(win.center(), { (rmk::f32)GAME_W, (rmk::f32)GAME_H }, {17, 15});

    // --- Loading sounds/music ---
    rmk::Music mus("assets/sound/music.mp3",      VOLUME);
    rmk::SFX   eatSound("assets/sound/eat.wav",   VOLUME);
    rmk::SFX   loseSound("assets/sound/lose.wav", VOLUME);
    rmk::SFX   winSound("assets/sound/win.wav",   VOLUME);

    // --- Loading the font and creating each panel's text ---
    rmk::font.load("opensans", "assets/font/OpenSans-Bold.ttf", 26);

    rmk::Text textCmd    ("opensans", { 16.0f });                          // anchored top-left of the "cmd" viewport
    rmk::Text textScore  ("opensans", { SIDE_W / 2.0f, PANEL_H / 2.0f });  // centered in the "score" viewport
    rmk::Text textStatus ("opensans", { SIDE_W / 2.0f, PANEL_H / 4.0f });  // centered (slightly higher) in "status"

    textScore.anchorX(rmk::anchor::x::center);
    textScore.anchorY(rmk::anchor::y::middle);
    textStatus.anchorX(rmk::anchor::x::center);
    textStatus.anchorY(rmk::anchor::y::middle);

    textCmd.color(rmk::color::raywhite);
    textScore.color(rmk::color::gold);
    textStatus.color(rmk::color::amber);

    // Controls text: written once, never changes during the game
    textCmd.write("COMMANDES\n\nW/Z : up\nA/Q : left\nS : down\nD : right\n\n0 : Restart\nP : Pause \n1 : stop mus. \n2 : start mus.");

    // --- Best score save/load (JSON via Data) ---
    rmk::Data dt;
    rmk::Timer saveTick(10);
    rmk::DataFile saveFile("highscore");

    saveTick.onTimeout.join([&] () {
        if (highscore <= score) saveFile.save(dt); // save best score every 10 second if has changed
    });

    if (saveFile.exist()) {
        saveFile.load(dt); // load saved highscore
        highscore = dt;    // implicit conversion Data -> imax
    }

    Snake::Segment head(zone.cell({8, 7})); // snake's starting position (cell 8,7)

    Snake snake(head, zone);

    Apple apple(zone.cell({3, 3}).center(), 30); // apple's starting position (cell 3,3)
    apple.respawn(zone, snake);                  // then moved to a random cell (never on the snake)

    // Resets the game to zero: called when '0' is pressed after a Game Over
    auto restart = [&]() {
        mus.play(-1);       // restart looping music
        loseSound.stop();   // stop the death sound if still playing

        snake.restart();
        apple.respawn(zone, snake);

        score      = 0;
        velocity   = {1, 0};
    };

    // Checkerboard background for the game grid
    rmk::usize idx = 0;
    for (auto& cell : zone.cells()) {
        cell.overridden = true;
        cell.color((idx++ % 2) ? primaryColor : secondaryColor);
    }

    // --- Keyboard controls ---
    // use onPressScan* for ZQSD / WASD control
    rmk::event.onPressA.join([&]()  { velocity = {-1, 0};  });
    rmk::event.onPressD.join([&]()  { velocity = { 1, 0};  });
    rmk::event.onPressW.join([&]()  { velocity = {0, -1};  });
    rmk::event.onPressS.join([&]()  { velocity = {0,  1};  });

    rmk::event.onPressP.join([&]() { snake.togglePause(); });
    rmk::event.onPress1.join([&]() { mus.stop(); });
    rmk::event.onPress2.join([&]() { mus.play(-1); });
    rmk::event.onPress0.join([&]() { if (!snake.isAlive()) restart(); }); // restart only allowed after Game Over

    rmk::event.onQuit.join([&]() { saveFile.save(dt); }); // save the best score to JSON on exit

    // Signal triggered on the "rising edge" of the snake's death
    // (fires exactly once, the moment isAlive() switches to false).
    rmk::Signal<> onDie;
    onDie.bindRising([&]() { return !snake.isAlive(); });
    onDie.join([&]() { mus.stop(); loseSound.play(); });

    // --- Organized into scenes: game logic kept separate from rendering ---
    rmk::Act   game;
    rmk::Scene logic;
    rmk::Scene renderer;

    // "logic" scene: everything related to game rules (no drawing here)
    logic.execute([&] () {
        snake.velocity(velocity);

        // Snake head / apple collision: grow, gain a point,
        // and update the best score if needed.
        if (snake.isAlive() && snake.headCenter() == apple.center()) {
            eatSound.play();
            snake.grow();
            apple.respawn(zone, snake);
            score++;

            if (rmk::imax(score) > highscore) {
                winSound.play();
                highscore = score;
                dt = highscore;
                textScore.color(rmk::color::gold); // score shown in gold while it's a new record
            }
        }

        // Status message: empty if alive and not paused, "PAUSE" or "GAME OVER" otherwise
        textStatus << (snake.isAlive() ? snake.isPaused() ? "PAUSE" : "" : "GAME OVER") << rmk::fmt::endl;
        // score message : print current score and best score
        textScore << "Score : " << score << rmk::fmt::nl << "Best   : " << highscore << rmk::fmt::endl;
    });

    // "renderer" scene: everything related to drawing (never changes game rules)
    renderer.execute([&] () {

        win.fill(zone);
        win.fill(apple);
        win.fill(snake);

        // Fill each text into its own viewport
        cmdViewport.fill(textCmd);
        scoreViewport.fill(textScore);
        statusViewport.fill(textStatus);
    });

    logic.add(snake); // add snake to scene logic

    game.add("logic",       logic); // add logic scene to game act
    game.add("renderer", renderer); // add render scene to game act

    mus.play(-1); // looping music from the start
    saveTick.repeat(true); // set repeating mode
    saveTick.start(); // start save timer

    // Main loop: every frame, update all scenes in "game"
    rmk::loop.execute(win, [&]() {
        game.updates();
    });

    rmk::loop.update(); // launch game
}